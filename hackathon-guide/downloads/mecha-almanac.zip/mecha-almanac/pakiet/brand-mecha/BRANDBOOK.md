Brandbook Mecha w Figmie: https://www.figma.com/design/hEDx3hQNYDELuJHc3L3fxC/Mecha---Brand-Guidelines?node-id=4153-637

To jest jedyne źródło brandu. W tym folderze są tylko pliki pomocnicze: fonty (Flecha M, Neue Haas), tokens.css i kadry ze strony mecha.xyz.
