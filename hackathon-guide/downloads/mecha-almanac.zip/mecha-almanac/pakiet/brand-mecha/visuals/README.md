# visuals/ — kadry ze strony mecha.xyz

Pobrane 2026-09-02 z publicznej strony Mecha (Webflow). Do użytku wewnętrznego na warsztat:
analiza języka obrazu i placeholdery w prototypach. Do materiałów zewnętrznych potrzebne są
oryginały z brandbooku. Lista źródeł: `SOURCES.txt`.

| Plik | Co przedstawia | Do czego się nadaje |
|---|---|---|
| `04-jfground.jpg` | kadr z systemu wizyjnego: taśma z odpadami, każdy obiekt obrysowany i podpisany klasą (Grade A Wood, Mixed Paper, Corrugated Cardboard, Colored LDPE, Drywall) | eko: jak wygląda "material intelligence"; tech: język etykiet i stanów; ogólnie: to jest prawdziwy obraz produktu, nie ilustracja |
| `09-AMPSortation_nosound-4.jpg` | robot delta nad taśmą z papierem w hali sortowni | eko: hero / tło pod dither; brand: przemysłowy motyw z brandbooku |
| `01`, `02`, `05`–`08` (avif/png) | warstwy graficzne ze strony (dither, ramki, tła) | brand: przykłady ditheru między ink i sand; sprawdź w przeglądarce |
| `03-Frame-….svg` | element wektorowy ze strony | brand: znak / ramka |

Wideo (nie pobrane, linki na stronie, hosting Widelab):

- Aescape Edit 3 (webm) i "Aescape – Video (1)" (mp4): ramię robota i stół, sesja; sport.
- "Tr Greenville Robot Edit" (webm): robot sortujący Tomorrow Recycling; eko.
- "Greenwaycomputervision Short2" (webm): system wizyjny na taśmie; eko / tech.
- "Reka 1 Grey" (webm): ramię na szarym tle; brand.

Zasada z brandbooku (za notatką w artefakcie Widelabu, s. 28): obraz Mecha to **przemysłowy motyw
zamieniony w półton / dither między ink (#262933) i sand (#E9E7DB)**. Zdjęcie bez ditheru jest
materiałem źródłowym, nie finalnym obrazem marki.
