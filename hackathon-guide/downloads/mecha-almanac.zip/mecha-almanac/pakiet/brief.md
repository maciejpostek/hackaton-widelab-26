# Almanac
**Tomorrow Landscaping · utrzymanie terenów zieleni · powierzchnia: desktop operacyjny + telefon w terenie + widok klienta**
Tagi: flota, harmonogram, mobile w terenie, greenfield

> Brief ćwiczeniowy napisany przez Widelab na potrzeby hackathonu Klekotki 2026. Nie jest to
> korespondencja od klienta ani realne zapytanie od Mecha. Kontekst firmowy jest prawdziwy
> (portfolio, pozycjonowanie, brand); produkt, value proposition, funkcje i cytaty użytkowników
> są zmyślone. Konkurencja i linki są prawdziwe, ale przed pokazaniem komukolwiek na zewnątrz
> trzeba je przeklikać. Oryginał po angielsku: `brief.en.json` (obok).

## Teaser

Jedna osoba, czterdzieści maszyn, dziewięć obiektów i pogoda, która przepisuje tydzień.

## Summary

Koszenie, nawadnianie, żywopłoty i drzewa w parkach, na kampusach i osiedlach komercyjnych,
robione przez floty małych autonomicznych maszyn zamiast ekipy dwunastu ludzi. Sezonowe,
zależne od pogody, na szalenie zmiennym terenie, i bez produktu, na który da się popatrzeć.

## Value proposition

Dla jednej osoby prowadzącej operacje na czterdziestu maszynach i dziewięciu obiektach to jedyne
miejsce, które mówi, co naprawdę dzieje się na zewnątrz, i przepisuje tydzień, kiedy robi to
pogoda. Klient w ogóle nie widzi floty; widzi, czy tereny wyglądają jak trzeba.

## W odróżnieniu od

Dashboardu do śledzenia floty pełnego zielonych kropek na mapie. To jest zbudowane wokół planu,
który ciągle się zmienia, i wokół faktu, że maszyny tracą kontakt, a interfejs musi to przyznać.

## Brief (napisany z perspektywy Mecha)

Utrzymanie terenów zieleni to dokładnie ten rodzaj biznesu, który kupujemy: rozdrobniony,
ograniczony dostępnością ludzi, prowadzony na papierze i telefonie, z właścicielami po
sześćdziesiątce szukającymi następcy. Sama praca jest bardzo powtarzalna i bardzo podatna na
automatyzację.

Nie istnieje warstwa, która pozwala jednej osobie nadzorować czterdzieści maszyn na dziewięciu
obiektach bez jeżdżenia na żaden z nich. Każde istniejące narzędzie to albo aplikacja do koszenia
dla właściciela domu, albo dashboard telematyczny zbudowany pod ciężarówki.

Dwoje odbiorców, celowo rozdzielonych. Operations lead potrzebuje maszyn. Facilities manager,
który nam płaci, nie może ich nigdy zobaczyć: kupił tereny, które w poniedziałek rano wyglądają
jak trzeba, a pokazanie mu naszej floty przenosi nasz problem na niego.

## Trzy use case'y

### Operations lead — "Gdzie jest jednostka 12?"
- Wyzwalacz: maszyna nie zgłosiła się od czterdziestu minut.
- Co robi: widzi "nieznane, 40 min" zamiast nieaktualnej zielonej kropki i decyduje, czy warto
  jechać.
- Dobrze wygląda tak: żadnej fałszywej pewności, żadnego niepotrzebnego wyjazdu.

### Operations lead — "We wtorek padało cały dzień."
- Wyzwalacz: pogoda unieważnia pół planu tygodnia.
- Co robi: przegląda przepisany plan jako diff, zatwierdza albo poprawia w jednym przejściu.
- Dobrze wygląda tak: tydzień przeplanowany w minuty, nie negocjowany przez telefon.

### Facilities manager — "Czy ktoś to w ogóle utrzymuje?"
- Wyzwalacz: comiesięczna kontrola albo skarga od najemcy.
- Co robi: otwiera jedną stronę: stan terenów, wykonane cykle, zużyta woda. Zamyka.
- Dobrze wygląda tak: nigdy nie dowiaduje się, czym jest wyjazd serwisowy.

## Konkurencja

| Nazwa | Typ | Link | Dlaczego ma znaczenie |
|---|---|---|---|
| Scythe Robotics | bezpośrednia | https://scytherobotics.com/ | Autonomiczne kosiarki komercyjne w modelu opłaty za użycie. Przejęte przez Autonomous Solutions (ASI); warto sprawdzić, jak to zmienia ich historię software'ową. |
| Graze | bezpośrednia | https://www.cbinsights.com/compare/graze-1-vs-scythe-robotics | Autonomiczne koszenie komercyjne, najczęściej porównywane ze Scythe. Link do strony porównawczej; potwierdź ich własną stronę przed użyciem. |
| Husqvarna | zasiedziała | https://www.husqvarna.com/ | Automower w skali konsumenckiej i pro, plus sieć dealerów. Domyślna odpowiedź, którą facilities manager już zna. |
| Kress | zasiedziała | https://kress.com/ | Komercyjne koszenie robotyczne pchane mocno przez firmy ogrodnicze. |
| Aspire | software | https://www.youraspire.com/ | Oprogramowanie biznesowe, na którym firmy ogrodnicze naprawdę pracują: harmonogram, ekipy, fakturowanie. To, od czego nasz widok operacyjny musi być lepszy albo z czym musi się integrować. |
| Samsara | software | https://www.samsara.com/ | Wzór telematyki floty, z którym każdy porówna nasz ekran operacyjny. Przydatne jako kontrast: zbudowane pod ciężarówki z kierowcami. |

## Pięć funkcji

### 1. Tablica floty z uczciwymi niewiadomymi
- Co to jest: każda maszyna: obiekt, stan, bateria, ostatni kontakt. Brak kontaktu czyta się
  "nieznane, 40 minut", nigdy "w porządku".
- Co zawiera: jawna nieaktualność na każdym wierszu. Grupowanie po obiekcie, nie po typie
  maszyny. Sortowanie po tym, co wymaga decyzji.
- Co jest w tym najważniejsze: uczciwość. Jedna nieuczciwa zielona kropka i operations lead
  przestaje wierzyć całemu ekranowi.
- Dla kogo: operations lead, cały dzień.

### 2. Mapa obiektu z prawdziwymi strefami
- Co to jest: koszenie, nawadnianie, przycinanie, zakaz wjazdu, z granicami, które coś znaczą:
  krawężniki, rabaty, drzewa, ścieżki.
- Co zawiera: edytowalne strefy. Różnice sezonowe per strefa. Strefy zakazane, które przetrwają
  przeplanowanie. Teren, który tłumaczy, dlaczego maszyna utknęła tam poprzednio.
- Co jest w tym najważniejsze: praca w terenie jest przestrzenna. Lista zadań nie wyrazi "nie ta
  rabata".
- Dla kogo: operations lead; technik terenowy też to czyta.

### 3. Plan sezonu i przepisanie przez pogodę
- Co to jest: co ma się dziać gdzie, tydzień po tygodniu, a kiedy przyjdzie deszcz albo upał,
  przepisany plan pokazany jako diff do zatwierdzenia.
- Co zawiera: diff, nie cicha zmiana. Co się przesunęło, co wypadło, co jest teraz zagrożone.
  Zatwierdzenie w jednym przejściu, z poprawkami.
- Co jest w tym najważniejsze: przeplanowanie to jest ta praca. Traktowanie go jak strony
  ustawień to sposób, w jaki te narzędzia zawodzą.
- Dla kogo: operations lead. Po tej funkcji nas oceni.

### 4. Kolejka wyjazdów i widok terenowy
- Co to jest: zablokowane maszyny uporządkowane po tym, ile kosztują obiekt, plus to, co technik
  widzi po przyjeździe: ostatni znany stan, co sprawdzić najpierw.
- Co zawiera: priorytet po wpływie na obiekt, nie po czasie. Odporność na brak sieci. Jedna ręka,
  w deszczu, w aucie. Zdjęcie przy zamknięciu.
- Co jest w tym najważniejsze: jedyny moment, w którym człowiek fizycznie się pojawia. Pomyłka
  kosztuje dwugodzinną jazdę.
- Dla kogo: technik terenowy, wysłany przez operations leada.

### 5. Widok klienta: efekt, nie flota
- Co to jest: stan terenów, wykonane cykle, zużyta woda. Bez maszyn, bez uptime'u, bez telemetrii.
- Co zawiera: rytm miesięczny. Zdjęcie jako dowód per strefa. Liczby, które facilities manager
  może przesłać w górę bez redagowania.
- Co jest w tym najważniejsze: kupił efekt. Nieobecność floty jest decyzją projektową.
- Dla kogo: facilities manager, i ten, komu raportuje.

## Pętla, którą produkt zamyka

| Krok | Co się dzieje |
|---|---|
| Plan | Plan sezonu tydzień po tygodniu, per obiekt i strefa. |
| Wyjazd maszyn | Maszyny w polu, tablica floty na żywo. |
| Pogoda | Deszcz albo upał unieważnia tydzień. |
| Przeplanowanie | Zaproponowany diff, operations lead zatwierdza. |
| Raport | Klient widzi stan, nie maszyny. |

## Wczesny feedback użytkowników

> Napisany przez nas, żeby zespół miał na co reagować. To nie są prawdziwe wypowiedzi.

- "Mapa mówiła, że wszystko jedzie. Dwie stały w rowie od lunchu." — operations lead, 9 obiektów
- "Nie chcę się nigdzie logować. Wyślijcie mi raz w miesiącu stronę, która mówi, że tereny są
  w porządku." — facilities manager, osiedle komercyjne
- "Jak pada, przebudowuję cały tydzień przez telefon. To jest mój wtorek, za każdym razem, kiedy
  pada." — operations lead
- "Zanim dojadę, już źle zgadłem, co jest nie tak. Połowa moich wyjazdów jest bez sensu."
  — technik terenowy

## Produkty referencyjne

| Produkt | Link | Czego się uczymy |
|---|---|---|
| John Deere Operations Center | https://www.deere.com/en/technology-products/precision-ag-technology/ | Sezonowe, zależne od pogody planowanie na maszynach i terenie: najbliższy dojrzały odpowiednik. |
| Samsara | https://www.samsara.com/ | Stan floty na jeden rzut oka. Przestudiuj, a potem usuń założenia o ciężarówkach. |
| Flighty | https://flighty.com/ | Uczciwość i konkret o niepewności zamiast pewnej, błędnej odpowiedzi. |
| Linear | https://linear.app/ | Przegląd proponowanej zmiany jako diff do zatwierdzenia, a nie stan, który po cichu się przesunął. |
