# Aescape Atlas
**Aescape · robotyczny masaż i regeneracja · powierzchnia: ekran na urządzeniu**
Tagi: device UI, mapa ciała 3D, sesja na żywo

> Brief ćwiczeniowy napisany przez Widelab na potrzeby hackathonu Klekotki 2026. Nie jest to
> korespondencja od klienta ani realne zapytanie od Mecha. Kontekst firmowy jest prawdziwy
> (portfolio, pozycjonowanie, brand); produkt, value proposition, funkcje i cytaty użytkowników
> są zmyślone. Konkurencja i linki są prawdziwe, ale przed pokazaniem komukolwiek na zewnątrz
> trzeba je przeklikać. Oryginał po angielsku: `brief.en.json` (obok).

## Teaser

Ekran, którym klient przy pierwszej wizycie steruje robotem, który już go dotyka.

## Summary

Aescape działa w ponad 150 lokalizacjach, w tym w Equinox i Ritz Carlton. To jest ekran na
urządzeniu, który w trakcie sesji dzielą klient i operator lokalu: jedyne miejsce, w którym
maszyna sama się tłumaczy.

## Value proposition

Dla kogoś, kto leży na stole po raz pierwszy, konsola zamienia onieśmielającą maszynę w coś,
czym da się sterować: pokazuje, co robot robi, co zrobi za chwilę i jak to zmienić, bez słowa
do kogokolwiek.

## W odróżnieniu od

Menu spa z gotowymi "programami", wybieranymi raz w recepcji, a potem wytrzymywanymi do końca.
Tu sesją steruje osoba, która w niej jest, w trakcie.

## Brief (napisany z perspektywy Mecha)

Sprzęt działa. Udowodniliśmy, że ludzie zapłacą za robotyczny masaż, i udowodniliśmy, że lokale
go zainstalują. Nie nadążyła za tym powierzchnia produktu.

Klient przy pierwszej wizycie kładzie się bez pojęcia, co zaraz stanie się z jego ciałem.
Operator lokalu, który nie jest fizjoterapeutą, nie ma szybkiego sposobu, żeby zamienić
"prawy bark, nie lewy" w coś, na co robot zareaguje. Dziś kompetencja maszyny jest niewidoczna,
a niewidoczna kompetencja czyta się jako ryzyko.

Przebudowaliśmy tej firmie go-to-market. Powierzchnia produktu jest następną rzeczą, która musi
nieść markę. Pokazuj, nie opowiadaj: zero wellnessowej waty, zero lawendy. Ludzie ufają tej
maszynie, bo jest precyzyjna, więc ekran ma wyglądać, jakby zaprojektowali go ci, którzy
zbudowali ramię.

## Trzy use case'y

### Pierwsza sesja — "Nie wiem, co to zaraz zrobi."
- Wyzwalacz: klient kładzie się, trzy minuty przed tym, jak ramię ruszy.
- Co robi: odpowiada na trzy pytania, zaznacza bark na mapie ciała, widzi podgląd pierwszych
  sześćdziesięciu sekund, zanim cokolwiek go dotknie.
- Dobrze wygląda tak: przestaje się spinać.

### W trakcie sesji — "Za mocno, ale nie przestawaj."
- Wyzwalacz: nacisk jest zły, klient leży twarzą w dół, z rękami pod głową.
- Co robi: dwa dotknięcia albo jedno słowo zmniejszają nacisk tylko w tej strefie, bez
  przerywania sesji.
- Dobrze wygląda tak: bez rozmowy, bez wzywania operatora.

### Operator lokalu — "Następny klient za cztery minuty."
- Wyzwalacz: sesja się kończy, pokój trzeba przygotować.
- Co robi: czyta podsumowanie, podaje klientowi jedno zdanie, potwierdza strefy zakazane
  przeniesione na następny raz.
- Dobrze wygląda tak: wygląda na eksperta, nie będąc nim.

## Konkurencja

| Nazwa | Typ | Link | Dlaczego ma znaczenie |
|---|---|---|---|
| Massage Robotics | bezpośrednia | https://www.massagerobotics.com/ | Najbliższy bezpośredni konkurent w komercyjnym masażu robotycznym. Dwa ramiona, sterowanie konwersacyjne. |
| Therabody | sąsiednia | https://www.therabody.com/ | Ma relację "regeneracyjną" z klientem przez urządzenia i aplikację. Nie robot, ale ustawia oczekiwania, jak ma działać oprogramowanie do regeneracji. |
| Hyperice | sąsiednia | https://hyperice.com/ | Sprzęt do regeneracji w klubach i drużynach. Konkuruje o tę samą podłogę w lokalu i tę samą linię budżetu. |
| Bodyfriend | sąsiednia | https://bodyfriend.com/ | Fotele masujące premium ze skanem zdrowia. Kategoria, która już nauczyła ludzi siadać do wnętrza maszyny. |
| Massage Envy | zasiedziała | https://www.massageenvy.com/ | Ludzki incumbent. Cokolwiek zaprojektujemy, musi pobić zdolność dobrego terapeuty do zwykłego zapytania. |

## Pięć funkcji

### 1. Mapa ciała, którą da się wskazać
- Co to jest: model ciała na poziomie grup mięśni. Dotknij, żeby zaznaczyć, gdzie boli i co
  jest poza zasięgiem, i patrz, nad czym robot pracuje teraz.
- Co zawiera: granulacja do grupy mięśni, nie mgliste regiony. Zaznaczone obszary, nacisk
  na obszar, trwałe strefy zakazane. Czytelne do góry nogami i pod kątem.
- Co jest w tym najważniejsze: żeby człowiek mógł wyrazić "tu, nie tam" szybciej, niż zdążyłby
  to powiedzieć.
- Dla kogo: najpierw klient, potem operator.

### 2. Teraz i za chwilę
- Co to jest: bieżąca strefa i nacisk, plus to, co ramię zrobi w następnych sześćdziesięciu sekundach.
- Co zawiera: widoczny horyzont czasu. Nazwa strefy zwykłymi słowami. Nacisk jako coś
  odczuwalnego, nie liczba od 1 do 10.
- Co jest w tym najważniejsze: zapowiadanie następnego ruchu, zanim nastąpi. To jest cały
  mechanizm zaufania.
- Dla kogo: klient przy pierwszej wizycie.

### 3. Zmiana w trakcie sesji
- Co to jest: nacisk w górę lub w dół, pomiń tę strefę, więcej czasu tutaj; dwa dotknięcia,
  osiągalne twarzą w dół, bez menu.
- Co zawiera: zmiany z zakresem (tylko ta strefa vs. reszta sesji). Natychmiastowe fizyczne
  potwierdzenie. Cofnij.
- Co jest w tym najważniejsze: żeby zmiana nie czuła się jak przerwanie. Żadnego modala,
  żadnego "czy na pewno".
- Dla kogo: każdy na stole, w każdej sesji.

### 4. Stop, zawsze
- Co to jest: jeden jednoznaczny element sterujący, który nigdy nie znika ze scrollem i nigdy
  nie prosi o potwierdzenie.
- Co zawiera: stała pozycja, wysoki kontrast, duży cel, działa w ciemnym pokoju bez okularów.
  Odróżniony od pauzy.
- Co jest w tym najważniejsze: to jest sterowanie, nie klauzula prawna. Wszystko powyżej jest
  niewiarygodne bez tego.
- Dla kogo: klient, i spokój operatora.

### 5. Zamknięcie, które przechodzi dalej
- Co to jest: co było pracowane, na co uważać i które strefy zakazane następna sesja uszanuje.
- Co zawiera: ludzki język, nie kliniczna dokumentacja. Jedno zdanie, które operator może
  powiedzieć głośno. Jawne przeniesienie, które klient potwierdza.
- Co jest w tym najważniejsze: zamiana jednej sesji w relację, nie w transakcję.
- Dla kogo: klient powracający, i wskaźnik ponownych rezerwacji lokalu.

## Pętla, którą produkt zamyka

| Krok | Co się dzieje |
|---|---|
| Wywiad | Trzy pytania, zanim cokolwiek się poruszy. |
| Mapa | Klient zaznacza obszary i strefy zakazane. |
| Sesja | "Teraz i za chwilę", stale widoczne. |
| Zmiana | Zmiana z zakresem, bez przerwania. |
| Zamknięcie | Podsumowanie plus to, co przechodzi dalej. |

## Wczesny feedback użytkowników

> Napisany przez nas, żeby zespół miał na co reagować. To nie są prawdziwe wypowiedzi.

- "Ciągle patrzyłam na ekran, żeby wiedzieć, kiedy się ruszy. Kiedy powiedział mi to pierwszy,
  przestałam się wzdrygać." — klientka przy pierwszej wizycie, 34 lata, pilot w Equinox
- "Powiedziałem głośno 'delikatniej' i nic się nie stało, bo nikogo nie było w pokoju. W tym
  momencie poczułem się głupio." — klient powracający, 41 lat
- "Ludzie pytają mnie, co to robi, a ja nie mam odpowiedzi. Czytam ten sam ekran, co oni."
  — operator lokalu, 6 miesięcy na sali
- "Przycisk stop to jedyny powód, dla którego położyłam się na stół. Nigdy go nie użyłam."
  — klientka przy pierwszej wizycie, 52 lata

## Produkty referencyjne

| Produkt | Link | Czego się uczymy |
|---|---|---|
| Whoop | https://www.whoop.com/ | Zamiana danych o ciele w jedno uczciwe zdanie dziennie zamiast dashboardu. |
| Tonal | https://www.tonal.com/ | Maszyna, która działa siłą na ciało i tłumaczy się w trakcie. |
| Oura | https://ouraring.com/ | Powściągliwość w danych okołomedycznych: co pokazać, co pominąć. |
| Apple Fitness+ | https://www.apple.com/apple-fitness-plus/ | Rytm "teraz i za chwilę" na ekranie, na który rzucasz okiem w trakcie wysiłku. |
