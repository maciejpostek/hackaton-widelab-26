# Catch
**Tomorrow Recycling · sortowanie z AI · powierzchnia: telefon + widok zakładu**
Tagi: mobile, wizualizacja przepływu, głos, na hali

> Brief ćwiczeniowy napisany przez Widelab na potrzeby hackathonu Klekotki 2026. Nie jest to
> korespondencja od klienta ani realne zapytanie od Mecha. Kontekst firmowy jest prawdziwy
> (portfolio, pozycjonowanie, brand); produkt, value proposition, funkcje i cytaty użytkowników
> są zmyślone. Konkurencja i linki są prawdziwe, ale przed pokazaniem komukolwiek na zewnątrz
> trzeba je przeklikać. Oryginał po angielsku: `brief.en.json` (obok).

## Teaser

Dwie sekundy dnia pracownika, wydane na trwałe ulepszenie robota.

## Summary

Osiem miesięcy automatyzacji podniosło odzysk materiału o około 25% i ograniczyło pracę ręczną.
Wąskim gardłem jest teraz to, co dzieje się, kiedy robot czegoś nie rozpoznaje, a osoba, która
zna odpowiedź, stoi trzy metry dalej.

## Value proposition

Dla pracownika na linii sortowania to są dwie sekundy, które na stałe czynią robota lepszym.
On oznacza to, co robot przepuścił; zakład dostaje maszynę, która poprawia się z każdą zmianą,
zamiast po cichu się psuć.

## W odróżnieniu od

Dotrenowywania modelu poza zakładem, miesiące później, z logów. Tu korekta ląduje na linii,
natychmiast, od jedynej osoby, która już zna odpowiedź.

## Brief (napisany z perspektywy Mecha)

Linia sortująca jedzie szybciej, niż ktokolwiek zdąży ją nadzorować. Kiedy ramię trafia na
obiekt, którego nie potrafi sklasyfikować, obiekt idzie do pozostałości, a model nic się z tego
nie uczy. Pomnóż to przez zmianę i masz mierzalną dziurę we wskaźniku odzysku.

Trzy metry dalej stoi człowiek, który dokładnie wie, co to był za obiekt. Dziś nie ma sposobu,
żeby powiedział to maszynie w czasie krótszym niż wzruszenie ramionami. Cała szansa leży
w zamknięciu tej luki: nie w lepszym modelu, w lepszych dwóch sekundach.

To jest też deklaracja pozycjonowania. Człowiek na naszej hali nie obsługuje maszyny. Uczy ją.
Projektujcie pod to.

## Trzy use case'y

### Pracownik linii — "Znowu przepuścił czarną tackę."
- Wyzwalacz: alert na telefonie w rękawicy, obiekt jeszcze na taśmie.
- Co robi: stuka w jeden z ośmiu dużych celów. Dwie sekundy, bez precyzji, bez menu.
- Dobrze wygląda tak: etykieta ląduje i on wie, że wylądowała.

### Pracownik linii — "Tego nie ma na liście."
- Wyzwalacz: obiekt, dla którego nikt nie ma kategorii.
- Co robi: mówi głośno, co to jest. Notatka głosowa przypina się do klatki.
- Dobrze wygląda tak: długi ogon zostaje złapany, zamiast zignorowany.

### Kierownik zmiany — "Jedziemy dziś czysto?"
- Wyzwalacz: początek zmiany i każda kolejna godzina.
- Co robi: czyta odzysk, zanieczyszczenie i to, gdzie materiał ucieka w tej chwili.
- Dobrze wygląda tak: naprawia stanowisko, zamiast pisać raport.

## Konkurencja

| Nazwa | Typ | Link | Dlaczego ma znaczenie |
|---|---|---|---|
| AMP | bezpośrednia | https://amprobotics.com/ | Punkt odniesienia w sortowaniu z AI: roboty plus warstwa analityczna. Najpewniej będzie w pokoju, kiedy zakład będzie nas porównywać. |
| Greyparrot | bezpośrednia | https://www.greyparrot.ai/ | Analityka składu odpadów na linii, coraz częściej warstwa danych, do której podłączają się inni producenci robotów. |
| Recycleye | bezpośrednia | https://recycleye.com/ | Wizja plus robotyczne zbieranie, pod retrofit istniejących MRF. |
| ZenRobotics (Terex) | bezpośrednia | https://www.terex.com/zenrobotics | Ciężkie zbieranie odpadów budowlanych i rozbiórkowych. Zachodzi też na naszą tezę o rozbiórkach. |
| Machinex SamurAI | zasiedziała | https://www.machinexrecycling.com/ | Sprzedawany przez uznanego producenta wyposażenia MRF: bezpieczny zakup, którego kierownik zakładu potrafi obronić. |
| Waste Robotics | bezpośrednia | https://www.therobotreport.com/how-waste-robotics-and-greyparrot-enable-more-effective-sorting-robots/ | Roboty sortujące z wizją firmy trzeciej. Cytowane przez publikację, nie ich stronę; sprawdź przed użyciem. |

## Pięć funkcji

### 1. Alert o pominięciu
- Co to jest: konkretny obiekt nie przeszedł klasyfikacji: zdjęcie, pozycja na linii, na
  telefonie w ciągu sekundy.
- Co zawiera: jeden obiekt na alert, nigdy zrzut kolejki. Pozycja tak, żeby dało się go jeszcze
  znaleźć. Domyślnie bez dźwięku; hala i tak jest głośna.
- Co jest w tym najważniejsze: szybkość. Jeśli pracownik musi szukać problemu, dwie sekundy już
  minęły.
- Dla kogo: pracownik linii, w trakcie pracy.

### 2. Dwusekundowa etykieta
- Co to jest: osiem dużych celów dla najczęstszych typów materiału. Kciuk w rękawicy, bez
  precyzji, bez menu, bez scrollowania.
- Co zawiera: osiem i tylko osiem. Ikona plus słowo, niezależnie od języka. Osiągalne jedną
  ręką. Cele w rozmiarze rękawicy roboczej, nie opuszka palca.
- Co jest w tym najważniejsze: to jest produkt. Wszystko inne istnieje po to, żeby to mogło się
  wydarzyć.
- Dla kogo: pracownik linii, także ten, którego pierwszym językiem nie jest angielski.

### 3. Głos na wszystko inne
- Co to jest: cokolwiek poza ośmioma celami mówi się głośno, zamiast pisać.
- Co zawiera: push-to-talk, działa w hałasie, transkrypcja przypięta do klatki do późniejszego
  przejrzenia. Bez interfejsu dyktowania.
- Co jest w tym najważniejsze: złapanie długiego ogona, gdzie odzysk naprawdę ucieka, bez
  odrywania rąk od linii.
- Dla kogo: pracownik linii; kierownik przegląda później.

### 4. Policzone, i zadziałało
- Co to jest: jednoznaczne potwierdzenie, że etykieta wylądowała. A później: "teraz rozpoznaje:
  47 złapanych, odkąd go nauczyłeś".
- Co zawiera: dwa momenty, nie jeden: natychmiastowe potwierdzenie i opóźniony dowód.
  Przypisane osobie, która nauczyła.
- Co jest w tym najważniejsze: nikt nie uczy dalej maszyny, która nigdy widocznie się nie uczy.
  To jest funkcja retencji.
- Dla kogo: pracownik linii. Jedyna funkcja zaprojektowana wyłącznie dla niego.

### 5. Przepływ materiału na żywo, z nazwanym miejscem straty
- Co to jest: wejście → etapy sortowania → odzyskane vs. pozostałość, z tym, gdzie materiał
  ucieka w tej chwili.
- Co zawiera: na żywo, nie dziennie. Jedno nazwane miejsce straty zamiast dwunastu wykresów.
  Liczby, które zakład śledzi: odzysk, zanieczyszczenie, przepustowość, przestoje.
- Co jest w tym najważniejsze: połączenie dwóch sekund jednego pracownika ze wskaźnikiem odzysku,
  za który właściciel płaci.
- Dla kogo: kierownik zmiany i właściciel zakładu.

## Pętla, którą produkt zamyka

| Krok | Co się dzieje |
|---|---|
| Pominięcie | Ramię trafia na obiekt, którego nie potrafi sklasyfikować. |
| Alert | Zdjęcie na telefonie najbliższego pracownika, poniżej sekundy. |
| Etykieta | Jeden z ośmiu celów albo głos. |
| Potwierdzenie | Kwit: policzone. |
| Dowód | Później: teraz rozpoznaje, N złapanych od tamtej pory. |

## Wczesny feedback użytkowników

> Napisany przez nas, żeby zespół miał na co reagować. To nie są prawdziwe wypowiedzi.

- "Nie będę zdejmować rękawic czterdzieści razy na zmianę. Jeśli to wymaga dwóch rąk, może
  równie dobrze nie istnieć." — pracownik linii, 11 lat w MRF-ach
- "Nikt nam nigdy nie powiedział, czy to coś zmieniło. Więc ludzie po tygodniu przestali się
  starać." — kierownik zmiany, o poprzednim pilocie
- "Osiem przycisków pokrywa może siedemdziesiąt procent. Belę rujnuje to dziwne." — pracownik
  linii, nocna zmiana
- "Nie potrzebuję dashboardu. Muszę wiedzieć, przy którym stanowisku mam stanąć." — kierownik
  zmiany

## Produkty referencyjne

| Produkt | Link | Czego się uczymy |
|---|---|---|
| Scandit | https://www.scandit.com/ | Przemysłowy UX rejestracji zaprojektowany pod rękawice, hałas i szybkość, nie pod polerkę. |
| Duolingo | https://www.duolingo.com/ | Pętla uczenia widoczna na tyle, żeby ludzie chcieli ją karmić. |
| Snapchat | https://www.snapchat.com/ | Rejestracja od kamery, gdzie migawka jest całym interfejsem. |
| Linear | https://linear.app/ | Przeglądanie długiego ogona bez zamiany interfejsu w arkusz. |
