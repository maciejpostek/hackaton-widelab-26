# Undo
**Rozbiórki i złom · nowy pion Mecha · powierzchnia: desktop na placu + przekazanie sterowania w terenie**
Tagi: operacje na placu, ryzyko, odzyskana wartość, greenfield

> Brief ćwiczeniowy napisany przez Widelab na potrzeby hackathonu Klekotki 2026. Nie jest to
> korespondencja od klienta ani realne zapytanie od Mecha. Kontekst firmowy jest prawdziwy
> (portfolio, pozycjonowanie, brand); produkt, value proposition, funkcje i cytaty użytkowników
> są zmyślone. Konkurencja i linki są prawdziwe, ale przed pokazaniem komukolwiek na zewnątrz
> trzeba je przeklikać. Oryginał po angielsku: `brief.en.json` (obok).

## Teaser

Najbrudniejsza robota, na jaką patrzyliśmy, i właśnie dlatego robot się tu broni.

## Summary

Rozbiórki konstrukcyjne i odzysk złomu. Ekipy pracują na termin, pod inspektorem
i ubezpieczycielem, na placu, którego konstrukcji nikt w pełni nie zna, dopóki nie zejdzie,
a każdy ładunek, który wyjeżdża, jest wart prawdziwe pieniądze.

## Value proposition

Dla kontraktora burzącego budynek pod karą umowną to zamienia rozbiórkę w mierzoną operację:
co jest zburzone, co jest niebezpieczne, co wyjechało i ile jest warte, z człowiekiem, który może
przejąć sterowanie w momencie, gdy maszyna trafi na coś, czego nie było na rysunkach.

## W odróżnieniu od

Aplikacji do postępu budowy. Tu materiał opuszczający plac jest traktowany jako przychód, nie
odpad, a ryzyko jest kierowane do konkretnej osoby, a nie kolorowane na czerwono.

## Brief (napisany z perspektywy Mecha)

Nasza teza jest prosta: im brudniejsza i bardziej niebezpieczna praca, tym łatwiej uzasadnić
robota i tym mocniej składa się ekonomia. Rozbiórki są skrajnym końcem tej krzywej i najłatwiejszą
historią, jaką kiedykolwiek opowiemy inwestorowi albo regulatorowi.

Dwie rzeczy są dziś źle wycenione. Po pierwsze bezpieczeństwo: ludzie są wewnątrz konstrukcji,
która jest celowo destabilizowana. Po drugie materiał: większość złomu jest wciąż klasyfikowana
na oko w skupie, co znaczy, że marżę rozstrzyga zgadywanie.

Tylko non-fiction. Prawdziwe maszyny, prawdziwe place, liczby, które kontraktor rozpozna. Jeśli
to wygląda jak koncept wideo o AI, to przegrało, a każdy kontraktor, który to zobaczy, będzie
to wiedział w cztery sekundy.

## Trzy use case'y

### Kontraktor na placu — "Zdążymy na termin?"
- Wyzwalacz: każdy poranek, pod karą umowną.
- Co robi: czyta postęp względem konstrukcji, która ciągle się zmienia, i ryzyko na jutro.
- Dobrze wygląda tak: o 7 rano wie, czy wołać kolejną maszynę.

### Operator zdalny — "Jest tam coś, czego nie powinno być."
- Wyzwalacz: maszyna trafia na nieoczekiwaną pustkę, instalację albo przęsło.
- Co robi: przejmuje sterowanie na placu, w rękawicach, jedną ręką, w deszczu, i oddaje je
  z powrotem.
- Dobrze wygląda tak: bez wstrzymania robót, bez incydentu.

### Inspektor bezpieczeństwa — "Pokażcie mi wtorek."
- Wyzwalacz: zaplanowana kontrola albo analiza incydentu.
- Co robi: wyciąga chronologiczny, odporny na manipulację zapis dnia.
- Dobrze wygląda tak: plac pracuje dalej.

## Konkurencja

| Nazwa | Typ | Link | Dlaczego ma znaczenie |
|---|---|---|---|
| Brokk | zasiedziała | https://www.brokk.com/ | Maszyna zdalna do rozbiórek, która zdefiniowała kategorię. Każdy kontraktor porównujący nas zaczyna tutaj. |
| Husqvarna DXR | zasiedziała | https://www.husqvarnaconstruction.com/us/demolition-equipment/demolition-robots/about/ | Zdalnie sterowane roboty rozbiórkowe z poważną siecią dealerów i wynajmu. |
| Conjet | sąsiednia | https://www.conjet.com/ | Roboty do hydrodemolicji: inna metoda, ten sam argument o trzymaniu ludzi poza konstrukcją. |
| Built Robotics | bezpośrednia | https://www.builtrobotics.com/ | Autonomia dokładana do ciężkiego sprzętu. Najbliższe naszej tezie o warstwie operacyjnej. |
| Teleo | bezpośrednia | https://www.teleo.ai/ | Nadzorowana autonomia i teleoperacja istniejących maszyn: wprost istotne dla naszej funkcji przekazania sterowania. |
| Procore | software | https://www.procore.com/ | To, na czym plac już pracuje. Nasze widoki zapisu i postępu albo się integrują, albo przegrywają. |
| OpenSpace | software | https://www.openspace.ai/ | Rejestracja placu i śledzenie postępu z obrazu: wzór na "co naprawdę zbudowano", z którego mamy się uczyć i odwrócić na "co naprawdę zniknęło". |

## Pięć funkcji

### 1. Postęp względem burzonej konstrukcji
- Co to jest: co jest zburzone, co następne, względem terminu, a plan zmienia się w miarę, jak
  budynek się rozpada.
- Co zawiera: plan, który spodziewa się rewizji. Postęp po elementach, nie procent ukończenia.
  Data kary zawsze w polu widzenia.
- Co jest w tym najważniejsze: statyczny plan na placu rozbiórki to kłamstwo. Interfejs musi
  spodziewać się, że jest w błędzie.
- Dla kogo: kontraktor na placu, każdego poranka.

### 2. Rejestr zagrożeń, który kieruje do osoby
- Co to jest: azbest, żywe instalacje, niestabilne przęsło: oznaczone przy znalezieniu, przypisane
  komuś z nazwiska, zamknięte przez kogoś z nazwiska.
- Co zawiera: kto znalazł i kto zamknął. Blokujące vs. nieblokujące. Zdjęcie w miejscu odkrycia.
  Nic nie zamyka się samo.
- Co jest w tym najważniejsze: to jest argument za robotem. Pokolorowanie zagrożenia i pójście
  dalej to to, co stary sposób już robi.
- Dla kogo: kontraktor, operator, inspektor; wszyscy trzej, i to jest trudna część.

### 3. Przekazanie sterowania przy interwencji
- Co to jest: maszyna trafia na nieoczekiwane; człowiek przejmuje sterowanie, potem je oddaje.
  Na placu, w rękawicach, jedną ręką, w deszczu.
- Co zawiera: jawny stan po obu stronach przekazania. Co maszyna widziała ostatnio. Czyste
  oddanie z zalogowanym powodem.
- Co jest w tym najważniejsze: człowiek jest zawsze, i nigdy nie siedzi przy biurku. Spraw to
  źle i nic innego nie ma znaczenia.
- Dla kogo: operator zdalny, w terenie.

### 4. Odzyskany materiał według klasy i to, co opuściło plac
- Co to jest: tonaż i klasa z przypisaną wartością, plus manifest każdego ładunku i miejsce,
  do którego pojechał.
- Co zawiera: klasa, nie tylko waga. Wartość po bieżących cenach. Manifest na poziomie ładunku
  z miejscem docelowym. Do uzgodnienia ze skupem.
- Co jest w tym najważniejsze: tu jest marża, i tu buduje się argument dla właściciela firmy,
  którą kupujemy.
- Dla kogo: kontraktor, skup i zespół inwestycyjny Mecha.

### 5. Dziennik dla inspektora
- Co to jest: eksportowalny, odporny na manipulację, chronologiczny. Zapis, nie dashboard.
- Co zawiera: tylko dopisywanie. Znaczniki czasu i autorstwo. Eksport do czegoś, co inspektor
  już akceptuje. Czytelne po wydruku.
- Co jest w tym najważniejsze: bez tego plac nie pracuje. To też najmniej efektowny ekran tutaj;
  zaprojektuj go mimo to.
- Dla kogo: inspektor bezpieczeństwa, ubezpieczyciel i prawnik kontraktora.

## Pętla, którą produkt zamyka

| Krok | Co się dzieje |
|---|---|
| Rozpoznanie | Co myślimy, że jest w środku, przed pierwszym uderzeniem. |
| Rozbiórka | Maszyny pracują, postęp po elementach. |
| Zagrożenie | Znalezione, oznaczone, skierowane do osoby. |
| Przekazanie | Człowiek przejmuje sterowanie, potem je oddaje. |
| Wyjazd | Materiał sklasyfikowany, ładunek w manifeście, dzień zapisany. |

## Wczesny feedback użytkowników

> Napisany przez nas, żeby zespół miał na co reagować. To nie są prawdziwe wypowiedzi.

- "Rysunki są złe na każdej robocie. Pytanie tylko, jak bardzo i jak szybko się dowiemy."
  — kontraktor rozbiórkowy, 22 lata
- "Jeśli mam się zatrzymać i zdjąć rękawicę, żeby potwierdzić ostrzeżenie, przestanę
  potwierdzać ostrzeżenia." — operator maszyny
- "Klasę zgadujemy w skupie. W złym miesiącu ta zgadywanka to cała marża." — kierownik placu
- "Dajcie mi coś, co da się wydrukować. Inspektor nie będzie się logował na waszą stronę."
  — kierownik placu

## Produkty referencyjne

| Produkt | Link | Czego się uczymy |
|---|---|---|
| Procore | https://www.procore.com/ | Poziom prowadzenia dokumentacji na budowie, łącznie z tym, jak to wygląda, kiedy jest za ciężkie. |
| OpenSpace | https://www.openspace.ai/ | Postęp z rejestracji rzeczywistości, a nie z tego, że ktoś wpisał procent. |
| Doxel | https://www.doxel.ai/ | Mierzony postęp względem planu i co robić, kiedy oba się nie zgadzają. |
| Waze | https://www.waze.com/ | Zagrożenia zgłaszane przez tego, kto jest najbliżej, wiarygodne, bo mają czas i miejsce. |
